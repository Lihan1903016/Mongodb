const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();

// registerBook
const registerSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String,
});

const RegisterBook = mongoose.model('RegisterBook', registerSchema);

module.exports = RegisterBook;

// Connect to MongoDB using Mongoose
mongoose.connect('mongodb+srv://Lihan1903016:Lihan2000@cluster0.dz92p7e.mongodb.net/TestDatabase', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => {
    console.log('MongoDB connected');
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err);
  });
  app.use(bodyParser.urlencoded({ extended: true }));
  app.use(express.static(path.join(__dirname, '../Mongodb Project')));
  app.use(express.static(path.join(__dirname,'./html')));
// Define a route to serve the index.html file
app.get('/', (req, res) => {
  res.sendFile(__dirname+ '/html/index.html');
});
//////////////////////////////////
// Handle POST requests to /register
app.post('/register', async (req, res) => {
  try {
    const Register = new RegisterBook({
      username: req.body.username,
      email: req.body.email,
      password: req.body.password,
    });

    // Save the document to the database
    await Register.save();

    res.redirect(req.get('referer')+'?response=Submitted');
  } catch (error) {
    // Handle errors and respond with an error message
    console.error('Error registering:', error);
    res.status(500).send('Registration failed');
  }
});
// Login route using email
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Find the user in the database by email
    const user = await RegisterBook.findOne({ email });

    if (!user) {
      // User not found
      return res.status(401).json({ success: false, message: 'Login failed' });
    }

    // Check if the provided password matches the stored password
    if (password === user.password) {
      // Successful login
      return res.json({ success: true, message: 'Login successful' });
    } else {
      // Password doesn't match
      return res.status(401).json({ success: false, message: 'Login failed' });
    }
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'An error occurred during login' });
  }
});





//////////////////////////////////

// Start the Express server
app.listen(10, () => {
  console.log(`http://localhost:10`);
});
